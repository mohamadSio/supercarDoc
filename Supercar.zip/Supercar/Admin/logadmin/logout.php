<?php
// deconnexion.php

session_start(); // Démarre la session
session_destroy(); // Détruit la session

// Redirige vers la page de connexion ou une autre page de votre choix
header("Location: ../formConne/index.php "); // Assurez-vous d'ajuster le chemin selon vos besoins
exit();
?>

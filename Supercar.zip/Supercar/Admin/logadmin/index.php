
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <section >
       <h1> Connexion</h1>
       <form action="loginAdmin.php" method="POST">  <!--on ne mets plus rien au niveau de l'action , pour pouvoir envoyé les données  dans la même page -->
           <label>Identifiant :</label>
           <input type="text" name="nom">
           <label >Mot de Passe :</label>
           <input type="password" name="password">
           <input type="submit" value="Valider" name="boutton-valider">
           <label>Mot de passe oublié</label>
       </form>
   </section> 
</body>
</html>